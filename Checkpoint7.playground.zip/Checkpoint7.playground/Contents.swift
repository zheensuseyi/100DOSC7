// Zheen H. Suseyi
// 09/26/2024
// Checkpoint 7
/*
 Your challenge is this: make a class hierarchy for animals, starting with Animal at the top, then Dog and Cat as subclasses, then Corgi and Poodle as subclasses of Dog, and Persian and Lion as subclasses of Cat.

 But there’s more:

 The Animal class should have a legs integer property that tracks how many legs the animal has.
 The Dog class should have a speak() method that prints a generic dog barking string, but each of the subclasses should print something slightly different.
 The Cat class should have a matching speak() method, again with each subclass printing something different.
 The Cat class should have an isTame Boolean property, provided using an initializer.
 */
import UIKit

// Making our new animal class
class Animal {
    // Both perfect and legs are variables that will be used in every animal class and inherited
    var perfect: Bool
    var legs: Int
    
    // initializing them
    init(perfect: Bool, legs: Int) {
        self.perfect = perfect
        self.legs = legs
    }
}

// Dog class which inherits from animal
class Dog: Animal {
    // Function that prints a dog speaking
    func dogSpeak() {
        print("BARK BARK BARK BARK BARK")
    }
}

// Corgi class which overrides the dogSpeak class to print a different sound, inherits from Dog
class Corgi: Dog {
    override func dogSpeak() {
        print("merppp merpp merpppp")
    }
}

// Poodle class which overrides the dogSpeak class to print a different sound, inherits from Dog

class Poodle: Dog {
    override func dogSpeak() {
        print("rawp rawp rawp")
    }
}

// Cat class which inherits from Animal
class Cat: Animal{
    
    // Some new variables, isCute and isTame
    var isCute: Bool
    
    // Return true, will override for lion class
    var isTame: Bool {
            return true
    }
    
    // Setting up our variables again, inheriting these variables from the animal class so have to use super
    init(isCute: Bool, perfect: Bool, legs: Int) {
        self.isCute = isCute
        super.init(perfect: perfect, legs: legs)
    }
    // Cat speak function
    func catSpeak() {
        print("MEOWWW")
    }
}

// Persion class which overrides the catspeak function, inherits from Cat
class Persian: Cat{
    override func catSpeak() {
                print("mewwwwww")
    }
}

// Lion class which overrides the catspeak function and the isTame variable, inherits from Cat

class Lion: Cat {
    override var isTame: Bool {
        print("Are Lions tame? Lions are extremely dangerous unless youre Mike Tyson")
        return false
    }
    
    override func catSpeak() {
                print("ROARRRRRR ROARRRRRRRR")
    }
}


// Making a new animal for each of our new classes and testing them to the fullest extent

let dog = Dog(perfect: true, legs: 4)
dog.dogSpeak()
print("This dog has \(dog.legs) legs wow!")

let corgi = Corgi(perfect: true, legs: 4)
corgi.dogSpeak()
print("This corgi has \(corgi.legs) legs wow!")


let poodle = Poodle(perfect: false, legs: 8)
poodle.dogSpeak()
print("This poodle has \(poodle.legs) legs wow!")

let cat = Cat(isCute: true, perfect: true, legs: 90)
print("This cat has \(cat.legs) legs wow!")
print("The cute detector is in operation! Lets see if theyre cute")
cat.catSpeak()
print(cat.isCute)
print("Is this animal tame?")
print(cat.isTame)


let persian = Persian(isCute: true, perfect: true, legs: 4)
print("This cat has \(persian.legs) legs wow!")
print("The cute detector is in operation! Lets see if theyre cute")
persian.catSpeak()
print(persian.isCute)
print("Is this animal tame?")
print(persian.isTame)

let lion = Lion(isCute: true, perfect: true, legs: 4)
print("This cat has \(lion.legs) legs wow!")
print("The cute detector is in operation! Lets see if theyre cute")
lion.catSpeak()
print(lion.isCute)
print("Is this animal tame?")
print(lion.isTame)



